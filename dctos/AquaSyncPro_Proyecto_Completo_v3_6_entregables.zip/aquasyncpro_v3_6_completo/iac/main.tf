# AquaSyncPro PoC v3.4 - Terraform baseline
terraform { required_providers { azurerm = { source = "hashicorp/azurerm" version = ">= 3.100.0" } } }
provider "azurerm" { features {} }
resource "azurerm_resource_group" "rg" { name = "aquasyncpro-poc-rg" location = "eastus" }
resource "azurerm_storage_account" "st" { name = "aquasyncpropocst" resource_group_name = azurerm_resource_group.rg.name location = azurerm_resource_group.rg.location account_tier = "Standard" account_replication_type = "LRS" }
resource "azurerm_iothub" "iot" { name = "aquasyncpro-poc-iothub" resource_group_name = azurerm_resource_group.rg.name location = azurerm_resource_group.rg.location sku { name = "S1" capacity = 1 } }
resource "azurerm_servicebus_namespace" "sb" { name = "aquasyncpro-poc-sb" location = azurerm_resource_group.rg.location resource_group_name = azurerm_resource_group.rg.name sku = "Basic" }
resource "azurerm_servicebus_queue" "commands" { name = "commands" namespace_id = azurerm_servicebus_namespace.sb.id default_message_ttl = "PT60S" dead_lettering_on_message_expiration = true max_delivery_count = 1 }
resource "azurerm_cosmosdb_account" "cosmos" { name = "aquasyncpro-poc-cosmos" location = azurerm_resource_group.rg.location resource_group_name = azurerm_resource_group.rg.name offer_type = "Standard" kind = "GlobalDocumentDB" consistency_policy { consistency_level = "Session" } geo_location { location = azurerm_resource_group.rg.location failover_priority = 0 } }
