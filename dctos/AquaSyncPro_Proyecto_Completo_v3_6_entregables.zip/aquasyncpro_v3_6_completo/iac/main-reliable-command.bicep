// AquaSyncPro PoC v3.4 - Variante A minima LOW cost
// Nombres fijos solicitados: aquasyncpro-poc-*
param location string = resourceGroup().location
resource storage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: 'aquasyncpropocst'
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: { accessTier: 'Hot' }
}
resource iothub 'Microsoft.Devices/IotHubs@2023-06-30' = {
  name: 'aquasyncpro-poc-iothub'
  location: location
  sku: { name: 'S1'; capacity: 1 }
  properties: {}
}
resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2024-05-15' = {
  name: 'aquasyncpro-poc-cosmos'
  location: location
  kind: 'GlobalDocumentDB'
  properties: { databaseAccountOfferType: 'Standard'; locations: [{ locationName: location; failoverPriority: 0; isZoneRedundant: false }] }
}
resource functionPlan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: 'aquasyncpro-poc-func-plan'
  location: location
  sku: { name: 'Y1'; tier: 'Dynamic' }
}
resource functionApp 'Microsoft.Web/sites@2023-12-01' = {
  name: 'aquasyncpro-poc-func'
  location: location
  kind: 'functionapp'
  properties: { serverFarmId: functionPlan.id; httpsOnly: true; siteConfig: { appSettings: [] } }
}

resource serviceBus 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' = {
  name: 'aquasyncpro-poc-sb'
  location: location
  sku: { name: 'Basic'; tier: 'Basic' }
}
resource commandQueue 'Microsoft.ServiceBus/namespaces/queues@2022-10-01-preview' = {
  name: 'commands'
  parent: serviceBus
  properties: { defaultMessageTimeToLive: 'PT60S'; deadLetteringOnMessageExpiration: true; maxDeliveryCount: 1 }
}
