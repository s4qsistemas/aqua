// AquaSyncPro PoC v3.1 - Bicep baseline (fixed names)
targetScope = 'resourceGroup'
param location string = resourceGroup().location

var prefix = 'aquasyncpro-poc'

resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: '${prefix}st'.replace('-', '')
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    accessTier: 'Hot'
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
  }
}

resource iothub 'Microsoft.Devices/IotHubs@2023-06-30' = {
  name: '${prefix}-iothub'
  location: location
  sku: { name: 'S1', capacity: 1 }
  properties: {}
}

resource servicebus 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' = {
  name: '${prefix}-sb'
  location: location
  sku: { name: 'Basic', tier: 'Basic' }
}

resource commandQueue 'Microsoft.ServiceBus/namespaces/queues@2022-10-01-preview' = {
  name: 'pump-commands'
  parent: servicebus
  properties: {
    defaultMessageTimeToLive: 'PT60S'
    deadLetteringOnMessageExpiration: true
  }
}

resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2024-05-15' = {
  name: '${prefix}-cosmos'
  location: location
  kind: 'GlobalDocumentDB'
  properties: {
    databaseAccountOfferType: 'Standard'
    capabilities: [ { name: 'EnableServerless' } ]
    locations: [ { locationName: location, failoverPriority: 0 } ]
  }
}

resource database 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2024-05-15' = {
  name: 'aquasyncpro'
  parent: cosmos
  properties: { resource: { id: 'aquasyncpro' } }
}

resource telemetry 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-05-15' = {
  name: 'telemetry'
  parent: database
  properties: { resource: { id: 'telemetry', partitionKey: { paths: ['/tenantSiteEquipmentKey'], kind: 'Hash' }, defaultTtl: 7776000 } }
}

resource state 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-05-15' = {
  name: 'equipmentState'
  parent: database
  properties: { resource: { id: 'equipmentState', partitionKey: { paths: ['/tenantId'], kind: 'Hash' } } }
}

// Add Function App, Static Web App and auth settings according to selected runtime/repository.
