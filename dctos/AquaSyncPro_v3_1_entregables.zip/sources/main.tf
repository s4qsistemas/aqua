# AquaSyncPro PoC v3.1 - Terraform baseline (fixed names)
terraform {
  required_providers { azurerm = { source = "hashicorp/azurerm", version = "~> 4.0" } }
}
provider "azurerm" { features {} }

variable "location" { default = "eastus" }
variable "resource_group_name" { default = "rg-aquasyncpro-poc" }

resource "azurerm_resource_group" "rg" { name = var.resource_group_name location = var.location }

resource "azurerm_storage_account" "st" {
  name                     = "aquasyncpropcst"
  resource_group_name      = azurerm_resource_group.rg.name
  location                 = azurerm_resource_group.rg.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  min_tls_version          = "TLS1_2"
  allow_nested_items_to_be_public = false
}

resource "azurerm_iothub" "iothub" {
  name                = "aquasyncpro-poc-iothub"
  resource_group_name = azurerm_resource_group.rg.name
  location            = azurerm_resource_group.rg.location
  sku { name = "S1" capacity = 1 }
}

resource "azurerm_servicebus_namespace" "sb" {
  name                = "aquasyncpro-poc-sb"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  sku                 = "Basic"
}

resource "azurerm_servicebus_queue" "commands" {
  name         = "pump-commands"
  namespace_id = azurerm_servicebus_namespace.sb.id
  default_message_ttl = "PT60S"
  dead_lettering_on_message_expiration = true
}

resource "azurerm_cosmosdb_account" "cosmos" {
  name                = "aquasyncpro-poc-cosmos"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  offer_type          = "Standard"
  kind                = "GlobalDocumentDB"
  capabilities { name = "EnableServerless" }
  consistency_policy { consistency_level = "Session" }
  geo_location { location = azurerm_resource_group.rg.location failover_priority = 0 }
}

resource "azurerm_cosmosdb_sql_database" "db" { name = "aquasyncpro" resource_group_name = azurerm_resource_group.rg.name account_name = azurerm_cosmosdb_account.cosmos.name }

resource "azurerm_cosmosdb_sql_container" "telemetry" {
  name                  = "telemetry"
  resource_group_name   = azurerm_resource_group.rg.name
  account_name          = azurerm_cosmosdb_account.cosmos.name
  database_name         = azurerm_cosmosdb_sql_database.db.name
  partition_key_paths   = ["/tenantSiteEquipmentKey"]
  default_ttl           = 7776000
}
# Add Function App and Static Web App according to repository/runtime decisions.
